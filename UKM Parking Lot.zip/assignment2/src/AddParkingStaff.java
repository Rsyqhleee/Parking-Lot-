import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTable;

public class AddParkingStaff extends JFrame implements ActionListener{

	public JFrame frame;
	private JTextField txtParkingID;
	private JTextField textField_2;
	private JTable tblMotorcycleLot = null;
	private JTable tblGeneralLot = null;
	private JTable tblManagerLotList= null;
	private JTable tblStaffLotList = null;
	private JComboBox cmbStudent;
	
	JRadioButton rdGeneralLot;
	JRadioButton rdMotorcycleLot;
	JRadioButton rdStaffLot;
	JRadioButton rdManagerLot;
	
	ButtonGroup buttonGroup;
	/**
	 * Launch the application.
	 */
	
	public static ArrayList<ParkingLot> motorcycleLotList = new ArrayList<ParkingLot>();
	public static ArrayList<ParkingLot> generalLotList = new ArrayList<ParkingLot>();
	public static ArrayList<ParkingLot> studentRegList = new ArrayList<ParkingLot>();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddParkingStaff window = new AddParkingStaff();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public AddParkingStaff() throws IOException {
		ReadStudentFile();
		ReadGeneralLotFile();
		ReadMotorcycleLotFile();
		
		//JOptionPane.showMessageDialog(null, generalLotList.size());
		//JOptionPane.showMessageDialog(null, motorcycleLotList.size());
		//JOptionPane.showMessageDialog(null, studentRegList.size());
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 899, 560);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel label = new JLabel("Parking ID:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label.setBounds(20, 70, 78, 14);
		frame.getContentPane().add(label);
		
		txtParkingID = new JTextField();
		txtParkingID.setColumns(10);
		txtParkingID.setBounds(97, 67, 174, 20);
		frame.getContentPane().add(txtParkingID);
		
		textField_2 = new JTextField();
		textField_2.setText("Student");
		textField_2.setEditable(false);
		textField_2.setColumns(10);
		textField_2.setBounds(95, 98, 180, 20);
		frame.getContentPane().add(textField_2);
		
		JLabel label_1 = new JLabel("Owner Type:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_1.setBounds(20, 101, 78, 14);
		frame.getContentPane().add(label_1);
		
		String[] array = new String[studentRegList.size()];
		for(int i = 0; i < studentRegList.size(); i++) {
		    ParkingLot pr = (ParkingLot)studentRegList.get(i);
		    Student s = (Student)pr.getinfo().getownerVehicle();
		    String vehicleType = "";
		    if(s.getVehicleInfo() instanceof Bus)
		    {
		    	vehicleType = "Bus";
		    }
		    else if(s.getVehicleInfo() instanceof Car)
		    {
		    	vehicleType = "Car";
		    }
		    else if(s.getVehicleInfo() instanceof Motorcycle)
		    {
		    	vehicleType = "Motorcycle";
		    }
		    else if(s.getVehicleInfo() instanceof Lorry)
		    {
		    	vehicleType = "Lorry";
		    }
		    
		    array[i] = pr.getinfo().getregisterId() +" - "+ pr.getinfo().getownerVehicle().getFullName()+" - "+vehicleType+" - "+pr.getinfo().getownerVehicle().getVehicleInfo().getmodel();
		}
		
		
		
		cmbStudent = new JComboBox(array);
		
		cmbStudent.setBounds(20, 154, 251, 22);
		cmbStudent.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String typeVehicle= "";
				// TODO Auto-generated method stub
				typeVehicle = checkVehicle(cmbStudent.getSelectedIndex());
				//JOptionPane.showMessageDialog(null,typeVehicle);
				
				if(typeVehicle.equals("Car")) {
					buttonGroup.clearSelection();
					rdGeneralLot.setEnabled(true);
					rdMotorcycleLot.setEnabled(false);
				}
				else if(typeVehicle.equals("Motorcycle")) {
					buttonGroup.clearSelection();
					rdGeneralLot.setEnabled(false);
					rdMotorcycleLot.setEnabled(true);
				}
				else if(typeVehicle.equals("Lorry"))
				{
					rdGeneralLot.setEnabled(false);
					rdMotorcycleLot.setEnabled(false);
				}
				else if(typeVehicle.equals("Bus")) {
					rdGeneralLot.setEnabled(false);
					rdMotorcycleLot.setEnabled(false);
				}
			}
			
		});
		frame.getContentPane().add(cmbStudent);
		
		JLabel label_2 = new JLabel("Select Vehicle / Owner:");
		label_2.setBounds(20, 129, 210, 14);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("Select Parking Lot:");
		label_3.setBounds(20, 220, 130, 14);
		frame.getContentPane().add(label_3);
		

		
		rdGeneralLot = new JRadioButton("General Lot");
		rdGeneralLot.setEnabled(false);
		rdGeneralLot.setActionCommand("General Lot");
		rdGeneralLot.setBounds(20, 241, 91, 23);
		frame.getContentPane().add(rdGeneralLot);
		
		rdStaffLot = new JRadioButton("Staff Lot");
		rdStaffLot.setEnabled(false);
		rdStaffLot.setActionCommand("Staff Lot");
		rdStaffLot.setBounds(20, 267, 77, 23);
		frame.getContentPane().add(rdStaffLot);
		
		rdManagerLot = new JRadioButton("Manager Lot");
		rdManagerLot.setEnabled(false);
		rdManagerLot.setActionCommand("Manager Lot");
		rdManagerLot.setBounds(20, 293, 98, 23);
		frame.getContentPane().add(rdManagerLot);
		
		rdMotorcycleLot = new JRadioButton("Motorcycle Lot");
		rdMotorcycleLot.setEnabled(false);
		rdMotorcycleLot.setActionCommand("Motorcycle Lot");
		rdMotorcycleLot.setBounds(20, 319, 109, 23);
		frame.getContentPane().add(rdMotorcycleLot);
		
		buttonGroup = new ButtonGroup();
		buttonGroup.add(rdGeneralLot);
		buttonGroup.add(rdStaffLot);
		buttonGroup.add(rdManagerLot);
		buttonGroup.add(rdMotorcycleLot);
		
		JButton btnAdd = new JButton("Add New Parking");
		btnAdd.setBounds(20, 437, 251, 23);
		frame.getContentPane().add(btnAdd);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(20, 471, 251, 23);
		frame.getContentPane().add(btnBack);
		
		JLabel lblNewLabel = new JLabel("Add Student Parking");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel.setBounds(20, 21, 227, 21);
		frame.getContentPane().add(lblNewLabel);
		
		tblMotorcycleLot = addRowMotorcycleLotData();
		tblMotorcycleLot.setBounds(337, 173, 448, 83);
		tblMotorcycleLot.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
		        if (tblMotorcycleLot.getSelectedRow() > -1) {
		            // print first column value from selected row
		        	int i = tblMotorcycleLot.getSelectedRow();
		           ParkingLot pl = (ParkingLot)motorcycleLotList.get(i);
		           
		           String [] choices = {"Yes","No"};
		           
		            int c = JOptionPane.showOptionDialog(null,"Remove Parking ?","Please Select",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,choices,choices[0]);
		            if(c==0)
		            {
		            	motorcycleLotList.remove(i);
		            	//JOptionPane.showMessageDialog(null,motorcycleLotList.size());
		            	writeMotorcycleListUpdate();
		                JOptionPane.showMessageDialog(null,"Delete Successfull");
		                try {
		                	
		        			generalLotList.clear();
		        			motorcycleLotList.clear();
		        			studentRegList.clear();
							refreshFrame();
							
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}  
		                
		            }
		            else if (c == 1) 
		            {
		            }
		        }
			}
		});
		frame.getContentPane().add(tblMotorcycleLot);
		
		tblGeneralLot = addRowGeneralLotData();
		tblGeneralLot.setBounds(337, 60, 448, 83);
		tblGeneralLot.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				// TODO Auto-generated method stub
		        if (tblGeneralLot.getSelectedRow() > -1) {
		            // print first column value from selected row
		        	int i = tblGeneralLot.getSelectedRow();
		           ParkingLot pl = (ParkingLot)generalLotList.get(i);
		           
		           String [] choices = {"Yes","No"};
		           
		            int c = JOptionPane.showOptionDialog(null,"Remove Parking ?","Please Select",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null,choices,choices[0]);
		            if(c==0)
		            {
		            	generalLotList.remove(i);
		            	writeGeneralListUpdate();
		                JOptionPane.showMessageDialog(null,"Delete Successfull");
		                try {
		                	
		        			generalLotList.clear();
		        			motorcycleLotList.clear();
		        			studentRegList.clear();
							refreshFrame();
							
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}  
		                
		            }
		            else if (c == 1) 
		            {
		            }
		        }
			}
		});
		frame.getContentPane().add(tblGeneralLot);
		
		JLabel lblMotorcycleLot = new JLabel("Motorcycle Lot:");
		lblMotorcycleLot.setBounds(337, 154, 130, 14);
		frame.getContentPane().add(lblMotorcycleLot);
		
		JLabel lblGneLot = new JLabel("General Lot:");
		lblGneLot.setBounds(337, 35, 130, 14);
		frame.getContentPane().add(lblGneLot);
		
		tblManagerLotList = new JTable();
		tblManagerLotList.setBounds(337, 289, 448, 83);
		frame.getContentPane().add(tblManagerLotList);
		
		JLabel lblManagerLot = new JLabel("Manager Lot:");
		lblManagerLot.setBounds(337, 271, 130, 14);
		frame.getContentPane().add(lblManagerLot);
		
		tblStaffLotList = new JTable();
		tblStaffLotList.setBounds(337, 411, 448, 83);
		frame.getContentPane().add(tblStaffLotList);
		
		JLabel lblStaffLot = new JLabel("Staff Lot:");
		lblStaffLot.setBounds(337, 392, 130, 14);
		frame.getContentPane().add(lblStaffLot);
		
		btnAdd.addActionListener(this);
		btnBack.addActionListener(this);		
	}
	
	
	public void ReadStudentFile() throws IOException
	{
		FileReader file = new FileReader("StudentRegistration.txt");
		try (BufferedReader in = new BufferedReader(file)) {
			String input = "";
			//staffList = null;
						
			while((input = in.readLine())!= null)
			{
				StringTokenizer word = new StringTokenizer(input,";");
				//Person
				String name = word.nextToken();
				String id = word.nextToken();
				int age = Integer.parseInt(word.nextToken());
				int phoneNum = Integer.parseInt(word.nextToken());
				
				//Student
				String matricNum = word.nextToken();
				int YearOfStudy = Integer.parseInt(word.nextToken());
				String course = word.nextToken();
				
				//Vehicle
				String vehicleType = word.nextToken();
				String model = word.nextToken();
				String regPlate = word.nextToken();
				String color = word.nextToken();
				//int yearRegistered = Integer.parseInt(word.nextToken());
			
	   			//Parking Registration
	   			String regID = word.nextToken();
				Vehicle v = null;
				
				if(vehicleType.equals("Bus")) //Bus
				{
					v = new Bus(model,regPlate,color);
				}
				else if(vehicleType.equals("Car"))//Car
				{
					v = new Car(model,regPlate,color);
				}
				else if(vehicleType.equals("Motorcycle"))//Motorcycle
				{
					v = new Motorcycle(model,regPlate,color);
				}
				else if(vehicleType.equals("Lorry"))//Lorry
				{
					v = new Lorry(model,regPlate,color);
				}
				String parkingID = word.nextToken();
				Person owner = new Student(name,id,age,phoneNum, v,matricNum,YearOfStudy,course);
				ParkingRegistration pr = new ParkingRegistration(regID,owner);
				ParkingLot pl = new GeneralLot(parkingID,pr);
					studentRegList.add(pl);
					
				
			}
		}
		catch(Exception ex)
		{
			
		}
	}
	
	
	public void ReadGeneralLotFile() throws IOException
	{
		FileReader file = new FileReader("GeneralLotListStudent.txt");
		try (BufferedReader in = new BufferedReader(file)) {
			String input = "";
			//staffList = null;
						
			while((input = in.readLine())!= null)
			{
				StringTokenizer word = new StringTokenizer(input,";");

					//Person
					String name = word.nextToken();
					String id = word.nextToken();
					int age = Integer.parseInt(word.nextToken());
					int phoneNum = Integer.parseInt(word.nextToken());
					
					//Student
					String matricNum = word.nextToken();
					int YearOfStudy = Integer.parseInt(word.nextToken());
					String course = word.nextToken();
					
					//Vehicle
					String vehicleType = word.nextToken();
					String model = word.nextToken();
					String regPlate = word.nextToken();
					String color = word.nextToken();
					//int yearRegistered = Integer.parseInt(word.nextToken());
				
		   			//Parking Registration
		   			String regID = word.nextToken();
					Vehicle v = null;
					
					if(vehicleType.equals("Bus")) //Bus
					{
						v = new Bus(model,regPlate,color);
					}
					else if(vehicleType.equals("Car"))//Car
					{
						v = new Car(model,regPlate,color);
					}
					else if(vehicleType.equals("Motorcycle"))//Motorcycle
					{
						v = new Motorcycle(model,regPlate,color);
					}
					else if(vehicleType.equals("Lorry"))//Lorry
					{
						v = new Lorry(model,regPlate,color);
					}
					String parkingID = word.nextToken();
					Person owner = new Student(name,id,age,phoneNum, v,matricNum,YearOfStudy,course);
					ParkingRegistration pr = new ParkingRegistration(regID,owner);
					ParkingLot pl = new GeneralLot(parkingID,pr);
					generalLotList.add(pl);
				
			}
		}
		catch(Exception ex)
		{
			
		}
	}
	public void ReadMotorcycleLotFile() throws IOException
	{
		FileReader file = new FileReader("MotorcycleLotListStudent.txt");
		try (BufferedReader in = new BufferedReader(file)) {
			String input = "";
			//staffList = null;
						
			while((input = in.readLine())!= null)
			{
				StringTokenizer word = new StringTokenizer(input,";");

					//Person
					String name = word.nextToken();
					String id = word.nextToken();
					int age = Integer.parseInt(word.nextToken());
					int phoneNum = Integer.parseInt(word.nextToken());
					
					//Staff
					String UKMper= word.nextToken();
					String position= word.nextToken();
					String staffappointment = word.nextToken();
					
					//Vehicle
					String vehicleType = word.nextToken();
					String model = word.nextToken();
					String regPlate = word.nextToken();
					String color = word.nextToken();
					//int yearRegistered = Integer.parseInt(word.nextToken());
				
		   			//Parking Registration
		   			String regID = word.nextToken();
					Vehicle v = null;
					
					if(vehicleType.equals("Bus")) //Bus
					{
						v = new Bus(model,regPlate,color);
					}
					else if(vehicleType.equals("Car"))//Car
					{
						v = new Car(model,regPlate,color);
					}
					else if(vehicleType.equals("Motorcycle"))//Motorcycle
					{
						v = new Motorcycle(model,regPlate,color);
					}
					else if(vehicleType.equals("Lorry"))//Lorry
					{
						v = new Lorry(model,regPlate,color);
					}
					String parkingID = word.nextToken();
					Person owner = new Staff(name,id,age,phoneNum, v,UKMper, position, staffappointment);
					ParkingRegistration pr = new ParkingRegistration(regID,owner);
					ParkingLot pl = new GeneralLot(parkingID,pr);
					motorcycleLotList.add(pl);
				
			}
		}
		catch(Exception ex)
		{
			
		}
	}
	
	public JTable addRowGeneralLotData()
	{
		JTable tblGeneralLotList;
		Object[] columns ={"Lot ID", "Name","IC","Program Level","Plate No.","Model","Vehicle Type"};
		Object data[][] = new Object[generalLotList.size()][7];
		//JOptionPane.showMessageDialog(null, generalLotStudentList.size());
		for (int i = 0; i < generalLotList.size(); i++)
		{
			ParkingLot item = (ParkingLot)generalLotList.get(i);
			
			Student s = (Student) item.getinfo().getownerVehicle();
			
			data[i][0] = item.getinfo().getregisterId();
			data[i][1] = item.getinfo().getownerVehicle().getFullName();
			data[i][2] = item.getinfo().getownerVehicle().getIdentityNumber();
			data[i][3] = s.getcourse();
			data[i][4] = item.getinfo().getownerVehicle().getVehicleInfo().getmodel();
			data[i][5] = item.getinfo().getownerVehicle().getVehicleInfo().getplateNo();
			
			if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Bus)
			{
				data[i][6] = "Bus";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Car)
			{
				data[i][6] = "Car";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Motorcycle)
			{
				data[i][6] = "Motorcycle";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Lorry)
			{
				data[i][6] = "Lorry";
			}
				
		}
		
		tblGeneralLotList = new JTable(data, columns);
		tblGeneralLotList.setCellSelectionEnabled(true);
		return tblGeneralLotList;
	}
	
	public JTable addRowMotorcycleLotData()
	{
		JTable tblMotorcycleLotList;
		Object[] columns ={"Lot ID", "Name","IC","Program Level","Plate No.","Model","Vehicle Type"};
		Object data[][] = new Object[motorcycleLotList.size()][7];
		//JOptionPane.showMessageDialog(null, generalLotStudentList.size());
		for (int i = 0; i < motorcycleLotList.size(); i++)
		{
			ParkingLot item = (ParkingLot)motorcycleLotList.get(i);
			
			Student s = (Student) item.getinfo().getownerVehicle();
			
			data[i][0] = item.getinfo().getregisterId();
			data[i][1] = item.getinfo().getownerVehicle().getFullName();
			data[i][2] = item.getinfo().getownerVehicle().getIdentityNumber();
			data[i][3] = s.getcourse();
			data[i][4] = item.getinfo().getownerVehicle().getVehicleInfo().getmodel();
			data[i][5] = item.getinfo().getownerVehicle().getVehicleInfo().getplateNo();
			
			if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Bus)
			{
				data[i][6] = "Bus";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Car)
			{
				data[i][6] = "Car";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Motorcycle)
			{
				data[i][6] = "Motorcycle";
			}
			else if(item.getinfo().getownerVehicle().getVehicleInfo() instanceof Lorry)
			{
				data[i][6] = "Lorry";
			}
				
		}
		
		tblMotorcycleLotList = new JTable(data, columns);
		tblMotorcycleLotList.setCellSelectionEnabled(true);
		return tblMotorcycleLotList;
	}
	
	public String checkVehicle(int i)
	{
		String check = "";
	    ParkingLot pr = (ParkingLot)studentRegList.get(i);
	    Student s = (Student)pr.getinfo().getownerVehicle();
	    String vehicleType = "";
	    if(s.getVehicleInfo() instanceof Bus)
	    {
	    	check = "Bus";
	    }
	    else if(s.getVehicleInfo() instanceof Car)
	    {
	    	check = "Car";
	    }
	    else if(s.getVehicleInfo() instanceof Motorcycle)
	    {
	    	check = "Motorcycle";
	    }
	    else if(s.getVehicleInfo() instanceof Lorry)
	    {
	    	check = "Lorry";
	    }
		return check;
	}
	
	//Rewrite Arraylist values to File
	public void writeListToFile(ParkingLot parking, ArrayList<ParkingLot> list) {
		try{
			String filename = "";
			
			if(parking instanceof GeneralLot)
			{
				filename = "GeneralLotListStudent.txt";
			}
			else if(parking instanceof ManagerLot)
			{
				filename = "ManagerLotList.txt";
			}
			else if(parking instanceof StaffLot)
			{
				filename = "StaffLotList.txt";
			}
			else if(parking instanceof MotorcycleLot) {
				
				filename = "MotorcycleLotListStudent.txt";
			}
			
			FileWriter file = new FileWriter(filename);
        	PrintWriter out = new PrintWriter(file);
        	
        	for(int i=0; i<list.size(); i++)
        	{
            	ParkingLot pl = (ParkingLot)list.get(i);
            	ParkingRegistration pr = pl.getinfo();
            	Student s = (Student) pr.getownerVehicle();
            	out.print(pr.getownerVehicle().getFullName()+";"+pr.getownerVehicle().getIdentityNumber()+";"+ pr.getownerVehicle().getAge()+";"+pr.getownerVehicle().getPhoneNumber()+";");
                out.print(s.getmatricNumber()+";"+s.getyear()+";"+s.getcourse()+";");
                
                if(pr.getownerVehicle().getVehicleInfo() instanceof Bus)
                {
                	out.print("Bus"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Motorcycle)
                {
                	out.print("Motorcycle"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Car)
                {
                	out.print("Car"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Lorry)
                {
                	out.print("Lorry"+";");
                }
                
                out.print(pr.getownerVehicle().getVehicleInfo().getmodel()+";"+pr.getownerVehicle().getVehicleInfo().getplateNo()+";"+pr.getownerVehicle().getVehicleInfo().getcolour()+";");
                out.print(pr.getregisterId()+";");
                out.print(pl.getlotId());
                out.println();
        	}
           JOptionPane.showMessageDialog(null,"List Updated.");
           out.close();
        }
        catch(IOException ex){System.out.println("There's no such file!");}

	}
	
	public void writeMotorcycleListUpdate() {
		try{
			String filename = "MotorcycleLotListStudent.txt";
			
			FileWriter file = new FileWriter(filename);
        	PrintWriter out = new PrintWriter(file);
        	
        	for(int i=0; i<motorcycleLotList.size(); i++)
        	{
            	ParkingLot pl = (ParkingLot)motorcycleLotList.get(i);
            	ParkingRegistration pr = pl.getinfo();
            	Student s = (Student) pr.getownerVehicle();
            	out.print(pr.getownerVehicle().getFullName()+";"+pr.getownerVehicle().getIdentityNumber()+";"+ pr.getownerVehicle().getAge()+";"+pr.getownerVehicle().getPhoneNumber()+";");
                out.print(s.getmatricNumber()+";"+s.getyear()+";"+s.getcourse()+";");
                
                if(pr.getownerVehicle().getVehicleInfo() instanceof Bus)
                {
                	out.print("Bus"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Motorcycle)
                {
                	out.print("Motorcycle"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Car)
                {
                	out.print("Car"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Lorry)
                {
                	out.print("Lorry"+";");
                }
                
                out.print(pr.getownerVehicle().getVehicleInfo().getmodel()+";"+pr.getownerVehicle().getVehicleInfo().getplateNo()+";"+pr.getownerVehicle().getVehicleInfo().getcolour()+";");
                out.print(pr.getregisterId()+";");
                out.print(pl.getlotId());
                out.println();
        	}
           JOptionPane.showMessageDialog(null,"List Updated.");
           out.close();
        }
        catch(IOException ex){System.out.println("There's no such file!");}

	}
	
	public void writeGeneralListUpdate() {
		try{
			String filename = "GeneralLotListStudent.txt";
			
			FileWriter file = new FileWriter(filename);
        	PrintWriter out = new PrintWriter(file);
        	
        	for(int i=0; i<generalLotList.size(); i++)
        	{
            	ParkingLot pl = (ParkingLot)generalLotList.get(i);
            	ParkingRegistration pr = pl.getinfo();
            	Student s = (Student) pr.getownerVehicle();
            	out.print(pr.getownerVehicle().getFullName()+";"+pr.getownerVehicle().getIdentityNumber()+";"+ pr.getownerVehicle().getAge()+";"+pr.getownerVehicle().getPhoneNumber()+";");
                out.print(s.getmatricNumber()+";"+s.getyear()+";"+s.getcourse()+";");
                
                if(pr.getownerVehicle().getVehicleInfo() instanceof Bus)
                {
                	out.print("Bus"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Motorcycle)
                {
                	out.print("Motorcycle"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Car)
                {
                	out.print("Car"+";");
                }
                else if(pr.getownerVehicle().getVehicleInfo() instanceof Lorry)
                {
                	out.print("Lorry"+";");
                }
                
                out.print(pr.getownerVehicle().getVehicleInfo().getmodel()+";"+pr.getownerVehicle().getVehicleInfo().getplateNo()+";"+pr.getownerVehicle().getVehicleInfo().getcolour()+";");
                out.print(pr.getregisterId()+";");
                out.print(pl.getlotId());
                out.println();
        	}
           JOptionPane.showMessageDialog(null,"List Updated.");
           out.close();
        }
        catch(IOException ex){System.out.println("There's no such file!");}

	}
	
	public void ClearComponents()
	{
		txtParkingID.setText("");
	}
	
	//Go to Menu
	public void goToMenu()
	{
		MainMenu main = new MainMenu();    
	    main.setVisible(true);
	    this.dispose();
		
	}
	public void refreshFrame() throws IOException
	{
		AddParkingStudent main = new AddParkingStudent();    
	    main.frame.setVisible(true);
	    this.dispose();
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("Add New Parking"))
		{
			try {
			int selectedIndex = cmbStudent.getSelectedIndex();
			String parkingType = buttonGroup.getSelection().getActionCommand();
			String parkingID = txtParkingID.getText();
		

		    
		   if(parkingID.equals(""))
		   {
			   JOptionPane.showMessageDialog(null,"Form is not complete.");
		   }
		   else
		   {
			    ParkingLot pr = (ParkingLot)studentRegList.get(selectedIndex);
			    
			    Student s = (Student)pr.getinfo().getownerVehicle();
		    
			if(parkingType.equals("General Lot"))
		    {
		    	ParkingLot parking = new GeneralLot(parkingID,pr.getinfo());
		    	generalLotList.add(parking);
		    	//JOptionPane.showMessageDialog(null,generalLotList.size());
		    	writeListToFile(parking, generalLotList);
				generalLotList.clear();
				motorcycleLotList.clear();
				studentRegList.clear();
		    	refreshFrame();
		    	
		    	
		    }
		    else if(parkingType.equals("Motorcycle Lot"))
		    {
		    	ParkingLot parking = new MotorcycleLot(parkingID,pr.getinfo());
		    	motorcycleLotList.add(parking);
		    	writeListToFile(parking, motorcycleLotList);
				generalLotList.clear();
				motorcycleLotList.clear();
				studentRegList.clear();
		    	refreshFrame();
		    }
		   
		   }
		   
		   ClearComponents();	
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(null,"Please fill up the form!");
			}
		}
		else if(e.getActionCommand().equals("Back"))
		{
			generalLotList.clear();
			motorcycleLotList.clear();
			studentRegList.clear();
			goToMenu();
		}
	}
}




public class Bus  extends Vehicle {

	public Bus(String m, String l, String r) {
		super(m,l,r) ;
	} 
	
}



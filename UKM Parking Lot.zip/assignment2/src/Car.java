
public class Car extends Vehicle {

	public Car(String m, String l, String r) {
		super(m, l, r);
		// TODO Auto-generated constructor stub
	} 
	
}



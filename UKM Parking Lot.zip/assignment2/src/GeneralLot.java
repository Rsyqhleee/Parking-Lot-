
public class GeneralLot extends ParkingLot {

		public GeneralLot(String t, ParkingRegistration b) {
			super(t, b);
			// TODO Auto-generated constructor stub
		}

}

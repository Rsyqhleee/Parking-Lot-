
public class Lorry extends Vehicle {

	public Lorry(String m, String l, String r) {
		super(m, l, r);
		// TODO Auto-generated constructor stub
	}

}



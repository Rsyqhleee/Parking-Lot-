import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;

public class MainMenu extends JFrame implements ActionListener{

	private JFrame frame;
	private JButton btnRegister;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu window = new MainMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 417, 262);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFTSM = new JLabel("FTSM Parking Registration");
		lblFTSM.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblFTSM.setBounds(117, 35, 219, 35);
		frame.getContentPane().add(lblFTSM);
		
		btnRegister = new JButton("Add New Parking");
		btnRegister.setBounds(144, 119, 121, 35);
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 11));
		frame.getContentPane().add(btnRegister);
		
		JLabel lblNewLabel = new JLabel("Welcome !!");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel.setBounds(168, 69, 95, 14);
		frame.getContentPane().add(lblNewLabel);
		
		btnRegister.addActionListener(this);
	}
     
	
	public void RegisterStudent() throws IOException {
		AddParkingStudent selectOwnerType = new AddParkingStudent();
		selectOwnerType.frame.setVisible(true);
		this.frame.dispose();
		
		}
	public void RegisterStaff() throws IOException   {
		AddParkingStaff selectOwnerType = new AddParkingStaff();
		selectOwnerType.setVisible(true);
		this.frame.dispose();
	}
	public void ChooseOwner() throws IOException  {
		Object[] options = {"Student" , "Staff"};
		
		int dialogResult = JOptionPane.showOptionDialog(null,"Choose owner type : ", "Register", 
			JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);
		
		if(dialogResult == 0) {
			RegisterStudent();
		}
		else if(dialogResult == 1) {
			RegisterStaff();
		}
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("Add New Parking")) {
			try {
				ChooseOwner();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
}



public class ManagerLot extends ParkingLot {

	public ManagerLot(String t, ParkingRegistration b) {
		super(t, b);
		// TODO Auto-generated constructor stub
	} 

}

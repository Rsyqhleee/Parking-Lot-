
public class Motorcycle extends Vehicle {

	public Motorcycle(String m, String l, String r) {
		super(m, l, r);
		// TODO Auto-generated constructor stub
	}

}




public class MotorcycleLot extends ParkingLot {

	public MotorcycleLot(String t, ParkingRegistration b) {
		super(t, b);
		// TODO Auto-generated constructor stub {
	}
}

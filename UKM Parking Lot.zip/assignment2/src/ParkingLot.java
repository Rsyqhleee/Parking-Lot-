
public class ParkingLot {
	private String lotId;
	private ParkingRegistration info;
	
	public ParkingLot(String t,ParkingRegistration b ) {
		lotId = t;
		info = b;
		
	}
	
	public String getlotId() {
		return lotId;
	}
	public ParkingRegistration getinfo() {
		return info;
	}
	public void setlotId(String t) {
		lotId = t;
	}
	public void setinfo(ParkingRegistration b) {
		info = b;
	}
	

}


public class ParkingRegistration {
	private String registerId;
	private Person ownerVehicle;
	
	public ParkingRegistration(String e, Person v) {
		registerId = e;
		ownerVehicle = v;
	}
	
	public String getregisterId() {
		return registerId;
	}
	public Person getownerVehicle() {
		return ownerVehicle;
	}
	public void setregisterId(String e) {
		registerId = e;
	}
	public void setownerVehicle(Person v) {
		ownerVehicle = v;
	}
}

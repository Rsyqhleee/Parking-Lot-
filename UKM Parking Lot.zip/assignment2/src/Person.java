
public class Person {


		private String fullName;
		private String identityNumber;
		private int age;
		private int phoneNumber;
		private Vehicle vehicleInfo;


		public Person (String f, String x, int a, int p, Vehicle v ) {
			fullName = f;
			identityNumber = x;
	        age = a;
	        phoneNumber = p;
	        vehicleInfo = v;
	        }

		public String getFullName() {
			return fullName;
		}
		
		public String getIdentityNumber() {
			return identityNumber;
		}

		public int getAge() {
			return age;
		}
		
		public int getPhoneNumber() {
			return phoneNumber;
		}
		
		public Vehicle getVehicleInfo() {
			return vehicleInfo;
		}
		public void setFullName( String f) {
			fullName = f;
		}
		public void setIdentityNumber(String x) {
			identityNumber = x;
		}
		public void setAge(int a) {
			age = a;
		}
		public void setPhoneNumber(int p) {
			phoneNumber = p;
		}
		
		
		public void setVehicleInfo(Vehicle v) {
			this.vehicleInfo = v;
		}

		
		
	}




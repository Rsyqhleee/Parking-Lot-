public class Staff extends Person {
	
	
	private String UKMper;
	private String position;
	private String staffappointment;
	
	public Staff(String f, String x, int a, int p, Vehicle v, String u, String o, String s) {
		super(f, x, a, p, v);
		// TODO Auto-generated constructor stub
		
		UKMper = u;
		position = o;
		staffappointment = s;
}
	public String getUKMper() {
		return UKMper;
	}
	public String getposition() {
		return position;
	}
	public String getStaffappointment() {
		return staffappointment;
	}
	public void setUKMper(String u) {
		UKMper = u;
	}
	public void setposition(String o) {
		position = o;
	}
	public void setstaffappointment(String s) {
		staffappointment = s;
	}

 

}


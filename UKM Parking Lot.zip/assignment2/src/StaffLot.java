
public class StaffLot extends ParkingLot {

	public StaffLot(String t, ParkingRegistration b) {
		super(t, b);
		// TODO Auto-generated constructor stub
	}

}

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class StaffRegistration extends JFrame implements ActionListener{

	private JFrame frame;
	private JTextField textStaff;
	private JTextField textfullName;
	private JTextField textAge;
	private JTextField textPhoneNum;
	private JTextField textIdentityNumber;
	private JTextField textUKMper;
	private JTextField textposition;
	private JTextField textRegisterId;
	private JTextField textModel;
	private JTextField textplateNo;
	private JTextField textColour;
	
	
	
	private JComboBox cmbVehicleType;
	private JComboBox cmbParkingLotType;
	private JComboBox cmbStaffType;
	
	public ArrayList<Person> staffRegList = new ArrayList<Person>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StaffRegistration window = new StaffRegistration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StaffRegistration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 10));
		frame.setBounds(100, 100, 600, 353);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblFTSMParkingRegistration = new JLabel("FTSM Parking Registration");
		lblFTSMParkingRegistration.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblFTSMParkingRegistration.setBounds(21, 23, 235, 30);
		frame.getContentPane().add(lblFTSMParkingRegistration);
		
		JLabel label_1 = new JLabel("Owner Type :");
		label_1.setBounds(21, 64, 82, 14);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("Owner Details");
		label_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_2.setBounds(21, 89, 93, 14);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("Name : ");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_3.setBounds(21, 114, 46, 14);
		frame.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("Age :");
		label_4.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_4.setBounds(21, 139, 46, 14);
		frame.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("Phone Number : ");
		label_5.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_5.setBounds(21, 164, 93, 14);
		frame.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("Identity Number :");
		label_6.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_6.setBounds(21, 189, 93, 14);
		frame.getContentPane().add(label_6);
		
		JLabel label_7 = new JLabel("Matric Number : ");
		label_7.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_7.setBounds(21, 214, 82, 14);
		frame.getContentPane().add(label_7);
		
		JLabel label_8 = new JLabel("Year of Study :");
		label_8.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_8.setBounds(21, 239, 93, 14);
		frame.getContentPane().add(label_8);
		
		textStaff = new JTextField();
		textStaff.setText("Staff");
		textStaff.setEditable(false);
		textStaff.setColumns(10);
		textStaff.setBounds(97, 61, 106, 20);
		frame.getContentPane().add(textStaff);
		
		textfullName = new JTextField();
		textfullName.setBounds(117, 111, 86, 20);
		frame.getContentPane().add(textfullName);
		textfullName.setColumns(10);
		
		textAge = new JTextField();
		textAge.setColumns(10);
		textAge.setBounds(117, 136, 86, 20);
		frame.getContentPane().add(textAge);
		
		textPhoneNum = new JTextField();
		textPhoneNum.setColumns(10);
		textPhoneNum.setBounds(117, 161, 86, 20);
		frame.getContentPane().add(textPhoneNum);
		
		textIdentityNumber = new JTextField();
		textIdentityNumber.setColumns(10);
		textIdentityNumber.setBounds(117, 186, 86, 20);
		frame.getContentPane().add(textIdentityNumber);
		
		textUKMper = new JTextField();
		textUKMper.setColumns(10);
		textUKMper.setBounds(117, 211, 86, 20);
		frame.getContentPane().add(textUKMper);
		
		textposition = new JTextField();
		textposition.setColumns(10);
		textposition.setBounds(117, 236, 86, 20);
		frame.getContentPane().add(textposition);
		
		JLabel label_9 = new JLabel("Vehicle Details");
		label_9.setFont(new Font("Tahoma", Font.BOLD, 11));
		label_9.setBounds(250, 89, 93, 14);
		frame.getContentPane().add(label_9);
		
		JLabel label_10 = new JLabel("Registration ID : ");
		label_10.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_10.setBounds(250, 114, 82, 14);
		frame.getContentPane().add(label_10);
		
		JLabel label_11 = new JLabel("Model : ");
		label_11.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_11.setBounds(250, 139, 46, 14);
		frame.getContentPane().add(label_11);
		
		JLabel label_12 = new JLabel("Plate Number : ");
		label_12.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_12.setBounds(250, 164, 82, 14);
		frame.getContentPane().add(label_12);
		
		JLabel label_13 = new JLabel("Colour : ");
		label_13.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_13.setBounds(250, 189, 46, 14);
		frame.getContentPane().add(label_13);
		
		JLabel label_14 = new JLabel("Vehicle Type : ");
		label_14.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_14.setBounds(250, 214, 82, 14);
		frame.getContentPane().add(label_14);
		
		JLabel label_15 = new JLabel("Parking Lot Type :");
		label_15.setFont(new Font("Tahoma", Font.PLAIN, 10));
		label_15.setBounds(250, 239, 93, 14);
		frame.getContentPane().add(label_15);
		
		textRegisterId = new JTextField();
		textRegisterId.setColumns(10);
		textRegisterId.setBounds(342, 111, 86, 20);
		frame.getContentPane().add(textRegisterId);
		
		textModel = new JTextField();
		textModel.setColumns(10);
		textModel.setBounds(342, 136, 86, 20);
		frame.getContentPane().add(textModel);
		
		textplateNo = new JTextField();
		textplateNo.setColumns(10);
		textplateNo.setBounds(342, 161, 86, 20);
		frame.getContentPane().add(textplateNo);
		
		textColour = new JTextField();
		textColour.setColumns(10);
		textColour.setBounds(342, 186, 86, 20);
		frame.getContentPane().add(textColour);
		
		String type[] = {"Car","Bus","Lorry","Motorcycle"};
		cmbVehicleType = new JComboBox(type);
		cmbVehicleType.setBounds(342, 211, 103, 20);
		frame.getContentPane().add(cmbVehicleType);
		
		String type2[] = {" ","General Lot","Manager Lot","Staff Lot","Motorcycle Lot"};
		cmbParkingLotType = new JComboBox(type2);
		cmbParkingLotType.setBounds(342, 236, 103, 20);
		frame.getContentPane().add(cmbParkingLotType);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(473, 210, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(473, 258, 89, 23);
		frame.getContentPane().add(btnClear);
		
		JLabel lblNewLabel = new JLabel("Staff Type :");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel.setBounds(250, 264, 73, 14);
		frame.getContentPane().add(lblNewLabel);
		
		String type3[] = {" ","Management Staff","Normal Staff"};
		cmbStaffType = new JComboBox();
		cmbStaffType.setBounds(342, 259, 103, 20);
		frame.getContentPane().add(cmbStaffType);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(342, 236, 103, 20);
		frame.getContentPane().add(comboBox);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int vehicleType = cmbVehicleType.getSelectedIndex();
		int parkingLotType = cmbParkingLotType.getSelectedIndex();
		
		if(e.getActionCommand().equals("SAVE")) {
			
			//Person
	        String fullName = textfullName.getText();
	        String identityNumber = textIdentityNumber.getText();
	        int Age = Integer.parseInt(textAge.getText());
	        int PhoneNum = Integer.parseInt(textPhoneNum.getText());
	    
	        //Staff
	        String position = textposition.getText(); 
	        String UKMper = textUKMper.getText();
	        String staffappointment = " ";
	        
	        //Vehicle
	        String plateNo = textplateNo.getText();
	    	String Model = textModel.getText();
	    	String Colour = textColour.getText();
	    	
	    	 Vehicle v = null;
	         String w = ""; 
	         //      if(vehicleType == 0) //empty column
	         //      {
	        //       	v = new ""();
	          //     }
	               if(vehicleType == 1) //Bus
	   			{
	   				v = new Bus(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 2)//Car
	   			{
	   				v = new Car(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 3)//Motorcycle
	   			{
	   				v = new Motorcycle(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 4)//Lorry
	   			{
	   				v = new Lorry(Model,plateNo,Colour);
	   			}
	   		
	               if(parkingLotType == 1) { //General lot
	   			 w = "GeneralLot";			 
	   		    }
	               else if(parkingLotType == 2) { //ManagerLot
	               	w = "ManagerLot";
	               }
	               else if(parkingLotType == 3) { //StaffLot
	               	w = "StaffLot";
	               }
	               else if(parkingLotType == 4) { // MotorcycleLot
	               	w = "MotorcycleLot";
	               }
	               
	        Person owner = new Staff(fullName,identityNumber,Age,PhoneNum, v ,UKMper,position, staffappointment );
	   		staffRegList.add(owner);
	   	    writeListToFile();
	   			}
	   	else if(e.getActionCommand().equals("NEW")) 
	   	{
	   			ClearComponents();
	   			goToMenu();
	   	}
	   	
	}
	
	public void goToMenu() {
		MainMenu main = new MainMenu();
		main.setVisible(true);
		this.dispose();
	}
	public void ClearComponents()
	{
		//Person
        textfullName.setText("");
        textIdentityNumber.setText("");
        textAge.setText("");
        textPhoneNum.setText("");
        
        //Staff
        textUKMper.setText(""); 
        textposition.setText("");
        
        //Vehicle
       textplateNo.setText("");
    	textModel.setText("");
    	textColour.setText("");
    	
	}

	   	private void writeListToFile() {
	   		// TODO Auto-generated method stub
	   		
	   		try{
	   			

	   			FileWriter file = new FileWriter("StaffRegistration.txt");
	            PrintWriter out = new PrintWriter(file);

	             for(int i=0; i<staffRegList.size(); i++) {
	               	
	    Person pr = (Person) staffRegList.get(i);
	    out.print(pr.getFullName()+";"+pr.getIdentityNumber()+";" + pr.getAge()+";"+pr.getPhoneNumber()+";");
	    out.print(((Staff) pr).getUKMper()+";"+((Staff) pr).getposition());
	             
	             }
				
	         
	   		
	   		}catch(Exception ex) {System.out.print(ex.getMessage());
	   		} 	
	   		}

}


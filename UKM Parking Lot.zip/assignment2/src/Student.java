public class Student extends Person {
		
		
		private String matricNumber;
		private int year;
		private String course;
		
		public Student(String f, String x, int a, int p,Vehicle v, String n, int y, String c) {
			super(f, x, a, p,v);
			// TODO Auto-generated constructor stub
	  
			matricNumber = n;
			year = y;
			course = c;
	}
		public String getmatricNumber() {
			return matricNumber;
		}
		public int getyear() {
			return year;
		}
		public String getcourse() {
			return course;
		}
		
		public void setmatricNumber(String n) {
			matricNumber = n;
		}
		public void setyear(int y) {
			year = y;
		}
		public void setcourse(String c) {
			course = c;
		}
	}




	
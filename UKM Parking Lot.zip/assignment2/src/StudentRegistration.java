import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JButton;

public class StudentRegistration extends JFrame implements ActionListener {

	private JFrame frame;
	private JTextField textStudent;
	private JTextField textIdentityNumber;
	private JTextField textPhoneNum;
	private JTextField textMatricNum;
	private JTextField textYear;
	private JTextField textfullName;
	private JTextField textAge;
	private JTextField textRegisterId;
	private JTextField textModel;
	private JTextField textplateNo;
	private JTextField textColour;
	private JTextField textCourse;
	
	private JComboBox cmbVehicleType;
	private JComboBox cmbParkingLotType;
	
	public ArrayList<Person> studentRegList = new ArrayList<Person>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentRegistration window = new StudentRegistration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentRegistration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.PLAIN, 10));
		frame.setBounds(100, 100, 602, 356);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("FTSM Parking Registration");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(24, 24, 255, 30);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Owner Type :");
		lblNewLabel_1.setBounds(24, 65, 82, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Owner Details");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(24, 90, 93, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Name : ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_3.setBounds(24, 115, 46, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Age :");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_4.setBounds(24, 140, 46, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Phone Number : ");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_5.setBounds(24, 165, 93, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Identity Number :");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_6.setBounds(24, 190, 93, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Matric Number : ");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_7.setBounds(24, 215, 82, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Year of Study :");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_8.setBounds(24, 240, 93, 14);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Course :");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_9.setBounds(24, 265, 46, 14);
		frame.getContentPane().add(lblNewLabel_9);
		
		textStudent = new JTextField();
		textStudent.setEditable(false);
		textStudent.setText("Student");
		textStudent.setBounds(101, 62, 106, 20);
		frame.getContentPane().add(textStudent);
		textStudent.setColumns(10);
		
		textIdentityNumber = new JTextField();
		textIdentityNumber.setColumns(10);
		textIdentityNumber.setBounds(114, 187, 93, 20);
		frame.getContentPane().add(textIdentityNumber);
		
		textPhoneNum = new JTextField();
		textPhoneNum.setBounds(114, 162, 93, 20);
		frame.getContentPane().add(textPhoneNum);
		textPhoneNum.setColumns(10);
		
		textMatricNum = new JTextField();
		textMatricNum.setBounds(121, 212, 86, 20);
		frame.getContentPane().add(textMatricNum);
		textMatricNum.setColumns(10);
		
		textYear = new JTextField();
		textYear.setBounds(101, 237, 106, 20);
		frame.getContentPane().add(textYear);
		textYear.setColumns(10);
		
		textCourse = new JTextField();
		textCourse.setBounds(74, 262, 133, 20);
		frame.getContentPane().add(textCourse);
		textCourse.setColumns(10);
		
		textfullName = new JTextField();
		textfullName.setBounds(68, 112, 139, 20);
		frame.getContentPane().add(textfullName);
		textfullName.setColumns(10);
		
		textAge = new JTextField();
		textAge.setBounds(68, 137, 139, 20);
		frame.getContentPane().add(textAge);
		textAge.setColumns(10);
		
		JLabel lblNewLabel_10 = new JLabel("Vehicle Details");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_10.setBounds(247, 90, 93, 14);
		frame.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Registration ID : ");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_11.setBounds(247, 115, 82, 14);
		frame.getContentPane().add(lblNewLabel_11);
		
		JLabel lblModel = new JLabel("Model : ");
		lblModel.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblModel.setBounds(247, 140, 46, 14);
		frame.getContentPane().add(lblModel);
		
		JLabel lblplateNo= new JLabel("Plate Number : ");
		lblplateNo.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblplateNo.setBounds(247, 165, 82, 14);
		frame.getContentPane().add(lblplateNo);
		
		JLabel lblColour = new JLabel("Colour : ");
		lblColour.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblColour.setBounds(247, 190, 46, 14);
		frame.getContentPane().add(lblColour);
		
		JLabel lblVehicleType = new JLabel("Vehicle Type : ");
		lblVehicleType.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblVehicleType.setBounds(247, 215, 82, 14);
		frame.getContentPane().add(lblVehicleType);
		
		textRegisterId = new JTextField();
		textRegisterId.setBounds(328, 112, 103, 20);
		frame.getContentPane().add(textRegisterId);
		textRegisterId.setColumns(10);
		
		textModel = new JTextField();
		textModel.setColumns(10);
		textModel.setBounds(303, 137, 128, 20);
		frame.getContentPane().add(textModel);
		
		textplateNo = new JTextField();
		textplateNo.setColumns(10);
		textplateNo.setBounds(328, 162, 103, 20);
		frame.getContentPane().add(textplateNo);
		
		textColour = new JTextField();
		textColour.setColumns(10);
		textColour.setBounds(303, 187, 128, 20);
		frame.getContentPane().add(textColour);
		
		String type[] = {" ","Car", "Bus", "Lorry", "Motorcycle"};
		cmbVehicleType = new JComboBox(type);
		cmbVehicleType.setBounds(328, 215, 103, 20);
		frame.getContentPane().add(cmbVehicleType);
		
		JLabel lblNewLabel_12 = new JLabel("Parking Lot Type :");
		lblNewLabel_12.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblNewLabel_12.setBounds(247, 253, 93, 14);
		frame.getContentPane().add(lblNewLabel_12);
		
		String type2[] = {" ","General Lot","Manager Lot","Staff Lot","Motorcycle Lot"};
		cmbParkingLotType = new JComboBox(type2);
		cmbParkingLotType.setBounds(338, 250, 93, 20);
		frame.getContentPane().add(cmbParkingLotType);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(464, 211, 89, 23);
		frame.getContentPane().add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(464, 261, 89, 23);
		frame.getContentPane().add(btnClear);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		int vehicleType = cmbVehicleType.getSelectedIndex();
		int parkingLotType = cmbParkingLotType.getSelectedIndex();
		
		if(e.getActionCommand().equals("SAVE")) {
			
			//Person
	        String fullName = textfullName.getText();
	        String identityNumber = textIdentityNumber.getText();
	        int Age = Integer.parseInt(textAge.getText());
	        int PhoneNum = Integer.parseInt(textPhoneNum.getText());
	    
	        //Student
	        String Course = textCourse.getText(); 
	        String MatricNum = textMatricNum.getText();
	        int Year = Integer.parseInt(textYear.getText());
	        
	        //Vehicle
	        String plateNo = textplateNo.getText();
	    	String Model = textModel.getText();
	    	String Colour = textColour.getText();
	    	
	    	 Vehicle v = null;
	         String w = ""; 
	         
	         //      if(vehicleType == 0) //empty column
	         //      {
	        //       	v = new ""();
	          //     }
	               if(vehicleType == 1) //Bus
	   			{
	   				v = new Bus(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 2)//Car
	   			{
	   				v = new Car(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 3)//Motorcycle
	   			{
	   				v = new Motorcycle(Model,plateNo,Colour);
	   			}
	   			else if(vehicleType == 4)//Lorry
	   			{
	   				v = new Lorry(Model,plateNo,Colour);
	   			}
	   		
	               if(parkingLotType == 1) { //General lot
	   			 w = "GeneralLot";			 
	   		    }
	               else if(parkingLotType == 2) { //ManagerLot
	               	w = "ManagerLot";
	               }
	               else if(parkingLotType == 3) { //StaffLot
	               	w = "StaffLot";
	               }
	               else if(parkingLotType == 4) { // MotorcycleLot
	               	w = "MotorcycleLot";
	               }
	               
	        Person owner = new Student(fullName,identityNumber,Age,PhoneNum, v, MatricNum,Year,Course );
	   		studentRegList.add(owner);
	   	    writeListToFile();
	   			}
		else if(e.getActionCommand().equals("NEW"))
		{
		ClearComponents();
		goToMenu();
		}
		
		
	   }
	
	public void goToMenu() {
		MainMenu main = new MainMenu();
		main.setVisible(true);
		this.dispose();
	}

	public void ClearComponents()
	{
		//Person
        textfullName.setText("");
        textIdentityNumber.setText("");
        textAge.setText("");
        textPhoneNum.setText("");
        
        //Student
        textCourse.setText(""); 
        textMatricNum.setText("");
        textYear.setText("");
        
        //Vehicle
       textplateNo.setText("");
    	textModel.setText("");
    	textColour.setText("");
    	
	}
	
	private void writeListToFile() {
	   		// TODO Auto-generated method stub
	   		
	   		try{
	   			

	   			FileWriter file = new FileWriter("StudentRegistration.txt");
	            PrintWriter out = new PrintWriter(file);

	             for(int i=0; i<studentRegList.size(); i++) {
	               	
	            	 Person pr = (Person) studentRegList.get(i);
	            	 out.print(pr.getFullName()+";"+pr.getIdentityNumber()+";" + pr.getAge()+";"+pr.getPhoneNumber()+";");
	            	 out.print(((Student) pr).getmatricNumber()+";"+((Student) pr).getyear()+((Student) pr).getcourse()+";");
				
	        
	        
	             }
		
	   		}catch(Exception ex)
	   		{
	   			System.out.println(ex.getMessage());
	   		}
	   		
	}
}




public class Vehicle {
	private String model;
	private String plateNo;
	private String colour;
	
		
	public Vehicle(String m,String l,String r) {
		model = m;
		plateNo = l;
		colour = r;
	}
	
	public String getmodel() {
		return model;
	}

	public String getplateNo() {
		return plateNo;
	}
	
	public String getcolour(){
		return colour;
		
	}
	public void setmodel(String m) {
		model = m;
	}
	public void setplateNo(String l) {
		plateNo = l;
	}
	public void setcolour(String r) {
		colour = r;
	}
	
	
	
}




